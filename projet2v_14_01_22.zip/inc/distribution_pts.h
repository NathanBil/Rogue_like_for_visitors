#ifndef __DISTRIBUTION_PTS__
#define __DISTRIBUTION_PTS__

	#include <MLV/MLV_all.h>

	#include "equipement.h"
	#include "potion.h"
	#include "perso.h"
	#include "terrain.h"
	#include "tresor.h"
	#include "boolean.h"
	#include "musique.h"
	#include "taille.h"


/*Renvoie la valeur */	
	char show_lvl_up();
	
#endif