#ifndef __TAILLE__
#define __TAILLE__

	/*taille des jauges liées aux hp/mp */
	#define JAUGE_SIZE 150
	/* taille de la fenêtre de jeu*/
	#define X 512
	#define Y 512
	
	void vide(void);

#endif