#include "../inc/terrain.h"
#include "../inc/perso.h"
#include "../inc/sauvegarde.h"
#include "../inc/monstre.h"
#include "../inc/msg.h"
#include "../inc/jeu.h"
#include "../inc/graphique.h"
#include "../inc/musique.h"
#include "../inc/distribution_pts.h"
#include "../inc/fouille_tresor.h"
#include "../inc/manip_inventaire.h"
#include "../inc/affiche_attribut.h"
#include "../inc/taille.h"
#include "../inc/clic.h"

int main(int argc, char **argv){


	play_dongeon_game();

	return 0;
}