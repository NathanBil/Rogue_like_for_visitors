/* enregistre les données du donjon*/
int save_dongeon(Donjon dongeon, FILE* file, int ){
	if(file == NULL)
		return 0;
	fwrite(dongeon->size, sizeof(int),1, file);
	fwrite(dongeon->etage_courant, sizeof(int),1, file);
	fwrite(&dongeon, sizeof(Donjon),1, file);
	fwrite(&dongeon, sizeof(Donjon),1, file);
	return 1;
	
}


/* enregistre les données du personnage dans le fichier que le user aura ouvert au préalable (valide)*/
void save_perso(Perso hero, FILE * file){
	/*fprintf(file, "hero: hp: %d , mp: %d , atk: %d , inte: %d , def: %d , exp: %d, lv: %d \n", hero.hp, hero.mp, hero.atk, hero.inte, hero.def, hero.exp, hero.lv);
	fprintf(file, "coord: x: %d , y: %d \n", hero.coord.x, hero.coord.y);
	fprintf(file, "armure : type: %d , atk: %d , def: %d , inte : %d \n" , hero.armure.type, hero.armure.atk, hero.armure.def, hero.armure.inte);
	fprintf(file, "baguette: type: %d , atk: %d , def: %d , inte : %d \n" , hero.baguette.type, hero.baguette.atk, hero.baguette.def, hero.baguette.inte);
	fprintf(file, "arme: type: %d , atk: %d , def: %d , inte : %d \n" , hero.arme.type, hero.arme.atk, hero.arme.def, hero.arme.inte);*/
	/* l'étoile indique la fin de la partie dans le fichier*/
	/*fprintf(file, "*");*/

	fwrite(&hero, sizeof(Perso),1, file);
	/*fprintf(file, "coord: x: %d , y: %d \n", hero.coord.x, hero.coord.y);
	fprintf(file, "armure : type: %d , atk: %d , def: %d , inte : %d \n" , hero.armure.type, hero.armure.atk, hero.armure.def, hero.armure.inte);
	fprintf(file, "baguette: type: %d , atk: %d , def: %d , inte : %d \n" , hero.baguette.type, hero.baguette.atk, hero.baguette.def, hero.baguette.inte);
	fprintf(file, "arme: type: %d , atk: %d , def: %d , inte : %d \n" , hero.arme.type, hero.arme.atk, hero.arme.def, hero.arme.inte);*/
}

/* enregistre les données chemin accessible au joueur et les caractéristiques des éléments présents le long de ce chemin*/
void save_chemin(Terrain chemin, FILE * file){
	/* affiche tout le chemin et ses données*/
	/*int i,j;
	fprintf(file, "chemin : \n");
	
	for(i=0;i<LONGUEUR;i++){
		for(j=0;j<LARGEUR;j++){
			fprintf(file, "cell : i : %d , j : %d , Celltype : %d \n" ,i,j, chemin.terrain[i][j].type);
			save_entity(chemin.terrain[i][j].entity, chemin.terrain[i][j].type, file);

		}
	}*/
	/* l'étoile indique la fin de la partie dans le fichier*/
	/*fprintf(file, "*");*/
	fwrite(&chemin, sizeof(Terrain),1, file);

}

/* enregistre les données chemin du dernier monstre trouvé (valide)*/
int save_monster_found(Coord monster_found, FILE * file){
	if(file == NULL)
		return 0;
	/*fprintf(file, "monster_found: x: %d , y: %d \n", monster_found.x, monster_found.y);*/
	/* l'étoile indique la fin de la partie dans le fichier*/
	/*fprintf(file, "*");*/

	fwrite(&monster_found, sizeof(Coord),1, file);
	return 1;
}

/* enregistre les données du donjon*/
int save_dongeon(Donjon dongeon, FILE* file){
	if(file == NULL)
		return 0;
	/*int i;
	fprintf(file, "dongeon: size: %d , etage_courant: %d \n", dongeon.size, dongeon.etage_courant);
	for(i = 0 ;i <TAILLE_DONGEON_MAX; i++){
		save_chemin(dongeon.etages[i], file);
	}*/
	/* l'étoile indique la fin de la partie dans le fichier*/
	/*fprintf(file, "*");*/

	fwrite(&dongeon, sizeof(Donjon),1, file);
	return 1;
	
}

/* fonction qui permet de donner au personnage les infos qui ont été sauvegardées sur lui*/
void load_perso(Perso *hero, FILE *file){
	if(file == NULL)
		printf("Echec chargement sauvegarde \n");
	fread(hero, sizeof(Perso),1 ,file);
	/*fscanf(file, "hero: hp: %d , mp: %d , atk: %d , inte: %d , def: %d , exp: %d, lv: %d ", &hero->hp, &hero->mp, &hero->atk, &hero->inte, &hero->def, &hero->exp, &hero->lv);
	fscanf(file, "coord: x: %d , y: %d ", &hero->coord.x, &hero->coord.y);
	fscanf(file, "armure : type: %d , atk: %d , def: %d , inte : %d ", (int *) &(hero->armure).type, &(hero->armure).atk, &(hero->armure).def, &(hero->armure).inte);
	fscanf(file, "baguette: type: %d , atk: %d , def: %d , inte : %d ",  (int *) &(hero->baguette).type, &(hero->baguette).atk, &(hero->baguette).def,&(hero->baguette).inte);
	fscanf(file, "arme: type: %d , atk: %d , def: %d , inte : %d", (int *) &(hero->arme).type, &(hero->arme).atk, &(hero->arme).def,&(hero->arme).inte);*/

}

int save_entity(Entity ent, Celltype type , FILE * file){
	if(file == NULL)
		return 0;
	/* cas où on enregistre un monstre*/
	if(type == MONSTER){
		fprintf(file, "entity type: MONSTER , atk: %d, hp: %d \n", ent.monster.atk, ent.monster.hp);
	}
	/* cas où on enregistre un trésor*/
	else if(type == TREASURE){
		/* cas où on enregistre un equipement*/
		if(ent.treasure.type_tresor == EQUIPEMENT){
			fprintf(file, "entity type: EQUIPEMENT , typeEquipement: %d , atk: %d , ", ent.treasure.item.eq.type, ent.treasure.item.eq.atk);
			fprintf(file, " def: %d , inte: %d , qual: %d  \n" , ent.treasure.item.eq.def, ent.treasure.item.eq.inte, ent.treasure.item.eq.qual);
		}

		/* cas où on enregistre une potion*/
		else if(ent.treasure.type_tresor == POTION){
			fprintf(file, "entity type: POTION , typePotion: %d , hp: %d , mp : %d , ", ent.treasure.item.pot.type, ent.treasure.item.pot.hp, ent.treasure.item.pot.mp);
			fprintf(file, "pourcentage: %d , critique: %d , exp: %d, tour: %d, " , ent.treasure.item.pot.pourcentage , ent.treasure.item.pot.critique, ent.treasure.item.pot.exp, ent.treasure.item.pot.tour);
			fprintf(file, "délai: %d \n", ent.treasure.item.pot.delai);
		}
		
	}
	return 1;
}

int monster_atk_perso(Perso * perso, Monster monster){

	int monster_damage, coup_critique;

	coup_critique = rand() % 100;

	if(coup_critique <= 5){
		coup_critique = 1;
	}else{
		coup_critique = 0;
	}


	printf("Dmage = %d\n", monster.atk);

	if(monster.atk == 0){
		monster_damage = 0;
	}else{
		monster_damage = ((monster.atk * 80) / 100) + (rand() % ((monster.atk * 40) / 100));
	}
	

	if(coup_critique == 1){
		monster_damage *= 3;
	}


	if(perso->hp <= monster_damage){
		perso->hp = 0;
	}else{
		perso->hp = perso->hp - monster_damage;
	}
	

	return monster_damage;
}

/* fonction qui crée un monstre avec des stats qui dépednent de l'étage*/
Monster generate_monster(int lvl){

	int rand_one, rand_two;
	Monster monster;

	rand_one = (rand() % 75 + (lvl * 10)) + 25;
	rand_two = (rand() % 75 + (lvl * 10)) + 25;

	monster.hp = rand_one;
	monster.atk = rand_two;
	monster.gain_exp = 0;

	return monster;	
}

/*gère la découverte d'un trésor*/
void decouverte(Perso * hero, Terrain * chemin, Coord tresor_found){

	Treasure tresor_found; 
	/* variable qui récupère le type de l'attaque choisie par le joueur */
	MLV_Keyboard_button atk;
	/* variable qui vérifie que le coup du user est valide ou non. Elle nécessaire pour les attaques magiques*/
	bool valide = false;
	/* on récupère les infos du trésor grâce à ses coordonnées*/
	tresor_found = chemin->terrain[monster_coord.x][monster_coord.y].entity.treasure;

	monster_atk_perso(hero, monster_found);
	/* tant que le joueur n'entre pas une touche valide on récupère sa saisie*/
	do{
		/*on récupère l'attaque choisie par le joueur dans "atk"*/
		MLV_wait_keyboard(&atk,NULL,NULL);
		printf("Veuillez choisir votre attaque : \n");
		printf(" 'q' pour magique, 's' pour normale  \n");
		barre_combat();
		if(atk == MLV_KEYBOARD_q){
			/* récupère la valeur de retour de l'attaque pour s'assurer qu'elle est valide*/
			/* pour une attaque magique ça dépend du nombre de mp du joueur*/
			valide = perso_atk_magique_monster(hero, &monster_found);
			if(valide == false){
				/*envoie un message sur l'écran du user si celui-ci n'a pas assez de mp*/
				msg_mp();
			}

		}
		else if(atk ==  MLV_KEYBOARD_s){
			/* récupère la valeur de retour de l'attaque pour s'assurer qu'elle est valide*/
			/* pour une attaque melee c'est toujours le cas normalement*/
			valide =  perso_atk_melee_monster(hero, &monster_found);
		}

	}while((atk != MLV_KEYBOARD_s  && atk != MLV_KEYBOARD_q) || valide == false);

	if(monster_found.hp <= 0){
		chemin->terrain[monster_coord.x][monster_coord.y].type = ROOM;
		chemin->terrain[monster_coord.x][monster_coord.y].entity.monster.atk = 0;
	}else{
		chemin->terrain[monster_coord.x][monster_coord.y].entity.monster = monster_found;
	}
}

/* affiche les différentes barrres liées aux actions possibles pendant un combat*/
/* on affiche aussi un triangle sur le monstre qui est en face du joueur*/
void barre_combat(Coord monster_coord){

	int coordx[3];
	int coordy[3];
	/*on détermine les coordonnées du triangle*/
	coordx[0] = monster_coord.x - 2;
	coordx[1] = monster_coord.x + 2;
	coordx[2] = monster_coord.x;
	coordy[0] = monster_coord.y;
	coordy[1] = monster_coord.y;
	coordy[2] = monster_coord.y-2;
	/*affiche le triangle autour du monstre*/
	MLV_draw_polygon(coordx,coordy,3 ,MLV_COLOR_GREEN);
	/* barre d'attaque normale */
	MLV_draw_filled_rectangle(10, Y-15, JAUGE_ATTAQUE, 8 , MLV_COLOR_SANDY_BROWN);
	/* affiche la touche pour l'attaque normal*/
	MLV_draw_text(10, Y-15, "d fouiller ", MLV_COLOR_WHITE);
	/* barre d'attaque magique */
	MLV_actualise_window();

}



/* cas où le joueur veut utiliser un objet*/
			else if(touche == MLV_KEYBOARD_q){
				/* cas equipement*/
				if(i == 0)
					equipe_equipement(perso, i, j);
				/* cas potion*/
				if(i == 1)
					bois_potion(perso,i,j);


			}


/* regarde si le joueur a changé de direction en plein combat, si oui on lui demande avec Wait_event s'il veut fuir , si oui il fuit*/
int valid_mouv(Perso *perso, MLV_Keyboard_button touche, Direction old_dir){

		if(touche == MLV_KEYBOARD_DOWN) {

			if(perso->direction != SUD){

				perso->direction = SUD;
				show_game(LONGUEUR, LARGEUR, *chemin, *perso);
				return TRUE;
			}
			/* on autorise le personnage a se déplacer si il entre dans une room, ou qu'il arrive sur une échelle*/
			if(chemin->terrain[perso->coord.x][perso->coord.y + 1].type == ROOM || chemin->terrain[perso->coord.x][perso->coord.y + 1].type == STAIR_DOWN 
				|| chemin->terrain[perso->coord.x][perso->coord.y + 1].type == STAIR_UP){
				deplacement_perso(perso, SUD, LONGUEUR, LARGEUR);
				show_game(LONGUEUR, LARGEUR, *chemin, *perso);
				return TRUE;
				
			}
			/* on verifie s'il y a un monstre à côté du héros, ici en haut*/
			else if(chemin->terrain[perso->coord.x][perso->coord.y + 1].type == MONSTER){
				
				return FALSE;
			}
		}

		else if(touche == MLV_KEYBOARD_LEFT ){
			
			if(perso->direction != OUEST){

				perso->direction = OUEST;
				show_game(LONGUEUR, LARGEUR, *chemin, *perso);
				return TRUE;
			}
			/* on autorise le personnage a se déplacer si il entre dans une room, ou qu'il arrive sur une échelle*/
			if(chemin->terrain[perso->coord.x - 1][perso->coord.y].type == ROOM || chemin->terrain[perso->coord.x - 1][perso->coord.y].type == STAIR_UP
				|| chemin->terrain[perso->coord.x - 1][perso->coord.y].type == STAIR_DOWN){
				
				deplacement_perso(perso, OUEST, LONGUEUR, LARGEUR);
				show_game(LONGUEUR, LARGEUR, *chemin, *perso);
				return TRUE;

			}

			/* on verifie s'il y a un monstre à côté du héros, ici  à gauche*/
			else if(chemin->terrain[perso->coord.x - 1][perso->coord.y].type == MONSTER){
				show_game(LONGUEUR, LARGEUR, *chemin, *perso);
			}
		}

		else if(touche == MLV_KEYBOARD_UP) {
			
			if(perso->direction != NORD){

				perso->direction = NORD;
				show_game(LONGUEUR, LARGEUR, *chemin, *perso);
				return TRUE;
			}
			/* on autorise le personnage a se déplacer si il entre dans une room, ou qu'il arrive sur une échelle*/
			if(chemin->terrain[perso->coord.x][perso->coord.y - 1].type == ROOM || chemin->terrain[perso->coord.x][perso->coord.y - 1].type == STAIR_DOWN ||
			 chemin->terrain[perso->coord.x][perso->coord.y - 1].type == STAIR_UP){
				
				deplacement_perso(perso, NORD, LONGUEUR, LARGEUR);
				show_game(LONGUEUR, LARGEUR, *chemin, *perso);
				return TRUE;
			}

			/* on verifie s'il y a un monstre à côté du héros, ici  en bas*/
			else if(chemin->terrain[perso->coord.x][perso->coord.y - 1].type == MONSTER){
				show_game(LONGUEUR, LARGEUR, *chemin, *perso);
				
			}
		}

		else if(touche == MLV_KEYBOARD_RIGHT ) {
			
			if(perso->direction != EST){

				perso->direction = EST;
				show_game(LONGUEUR, LARGEUR, *chemin, *perso);
				return TRUE;
			}
			/* on autorise le personnage a se déplacer si il entre dans une room, ou qu'il arrive sur une échelle*/
			if(chemin->terrain[perso->coord.x + 1][perso->coord.y].type == ROOM || chemin->terrain[perso->coord.x + 1][perso->coord.y].type == STAIR_DOWN
				|| chemin->terrain[perso->coord.x + 1][perso->coord.y].type == STAIR_UP){

				deplacement_perso(perso, EST, LONGUEUR, LARGEUR);
				show_game(LONGUEUR, LARGEUR, *chemin, *perso);
				return TRUE;
			}

			/* on verifie qu'il y a un monstre à côté du héros, ici à sa droite*/
			else if(chemin->terrain[perso->coord.x + 1][perso->coord.y].type == MONSTER){
				show_game(LONGUEUR, LARGEUR, *chemin, *perso);
				
			}
		}
		
		return FALSE;

}

/* regarde si le joueur a changé de direction en plein combat, si oui on lui demande avec Wait_event s'il veut fuir , si oui il fuit*/
int fuite_mouv(Perso *perso, MLV_Keyboard_button touche, Direction old_dir, Terrain * chemin, int limit_x, int limit_y, Potion tab_potion[MAX_USED_POTION]){
	int res;
	/* vérifie si le héros veut toujours se battre*/
	int resume;
	Coord monster_coords;
	/* on constate que le joueur a changé de direction et qu'il n'est plus orienté vers un monstre*/
	resume = test_fight(*hero, * chemin, &monster_coords);
	if(perso->direction != old_dir && resume == 0){
		/* on demande au joueur s'il veut fuir */
		res =  wait_fuite_direction(perso);
		/*cas où il veut fuir*/
		if(res == TRUE){
			MLV_actualise_window();
			return TRUE;
		}
		/* on le remet dans une position où il est à face à un monstre*/
		else{
			perso->direction = old_dir;
		}
		
		/* le joueur cherche à fuir*/
		return res;
		
		if(res == 8)
			 TRUE;
	}
	/* cas où le joueur n'a pas changé de direction par rapport à avant*/
	return FALSE;

		

}

/* permet de passer de coordonnées de coord à une position sur l'écran*/
/* renvoie la nouvelle coord*/
int reecrire_coordx_monster(int x, Perso hero){
	if(hero.direction == EST)
		return ((x * LONGUEUR/2)/hero.coord.x)+30;
	else if(hero.direction == OUEST)
		return ((x * X/2)/hero.coord.x)-20;
	return ((x * X/2)/hero.coord.x);
}

/* permet de passer de coordonnées de coord à une position sur l'écran*/
/* renvoie la nouvelle coordonnée*/
int reecrire_coordy_monster(int y, Perso hero){
	if(hero.direction == SUD)
		return ((y * Y/2)/hero.coord.y)+30;
	else if(hero.direction == NORD)
		return ((y * Y/2)/hero.coord.y)-30;
	return ((y * Y/2)/hero.coord.y);

}

/* permet de passer de coordonnées de coord à une position sur l'écran*/
/* renvoie la nouvelle coord*/
int reecrire_coordx_perso(int x, Perso hero){
	if(hero.direction == EST)
		return ((x * X/2)/hero.coord.x);
	else if(hero.direction == OUEST)
		return ((x * X/2)/hero.coord.x);
	return ((x * X/2)/hero.coord.x);
}

/* permet de passer de coordonnées de coord à une position sur l'écran*/
/* renvoie la nouvelle coord*/
int reecrire_coordy_perso(int y, Perso hero){
	if(hero.direction == SUD)
		return ((y * Y/2)/hero.coord.y);
	else if(hero.direction == NORD)
		return ((y * Y/2)/hero.coord.y);
	return ((y * Y/2)/hero.coord.y);

}



if(chemin->terrain[tresor_found.x][tresor_found.y].entity.treasure[i].type_tresor == EQUIPEMENT){
			/* on vérifie s'il y a un emplacement vide*/
			empty_place = find_empty_place_1(*hero, &x, &y);
			/* s'il y a un emplacement vide alors on ajoute l'équipement*/
			if(empty_place == TRUE){
				show_equipement(chemin->terrain[tresor_found.x][tresor_found.y].entity.treasure[i].item.eq);
				eq1 = chemin->terrain[tresor_found.x][tresor_found.y].entity.treasure[i].item.eq;
				add_equipement_invent(hero, eq1,x,y);
			}
			else
				printf("Votre inventaire des équipements est plein, veuillez le vider pour ajouter un objet\n");
		}
		/* si le deuxième objet est un équipement alors...*/
		if(chemin->terrain[tresor_found.x][tresor_found.y].entity.treasure[1].type_tresor == EQUIPEMENT)
		{
			/* on vérifie s'il y a un emplacement vide*/
			empty_place = find_empty_place_1(*hero, &x, &y);
			/* s'il y a un emplacement vide alors on ajoute l'équipement*/
			if(empty_place == TRUE){
				show_equipement(chemin->terrain[tresor_found.x][tresor_found.y].entity.treasure[1].item.eq);
				eq1 = chemin->terrain[tresor_found.x][tresor_found.y].entity.treasure[1].item.eq;
				add_equipement_invent(hero, eq1,x,y);

			}
			else
				printf("Votre inventaire des équipements est plein, veuillez le vider pour ajouter un objet\n");
		}
		if(chemin->terrain[tresor_found.x][tresor_found.y].entity.treasure[0].type_tresor == POTION){
			/* on vérifie s'il y a un emplacement vide*/
			empty_place = find_empty_place_2(*hero, &x, &y);
			/* s'il y a un emplacement vide alors on ajoute la potion*/
			if(empty_place == TRUE){
				show_potion(chemin->terrain[tresor_found.x][tresor_found.y].entity.treasure[0].item.pot);
				pot1 = chemin->terrain[tresor_found.x][tresor_found.y].entity.treasure[0].item.pot;
				add_potion_invent(hero, pot1,x,y);
				return TRUE;
			}
			else
				printf("Votre inventaire des potions est plein, veuillez le vider pour ajouter un objet\n");
		}

		if(chemin->terrain[tresor_found.x][tresor_found.y].entity.treasure[1].type_tresor == POTION){
			/* on vérifie s'il y a un emplacement vide*/
			empty_place = find_empty_place_2(*hero, &x, &y);
			/* s'il y a un emplacement vide alors on ajoute la potion*/
			if(empty_place == TRUE){
				show_potion(chemin->terrain[tresor_found.x][tresor_found.y].entity.treasure[1].item.pot);
				pot1 = chemin->terrain[tresor_found.x][tresor_found.y].entity.treasure[1].item.pot;
				add_potion_invent(hero, pot1,x,y);
				return TRUE;
			}
			else
				printf("Votre inventaire des potions est plein, veuillez le vider pour ajouter un objet\n");
		}



/* fonction qui gère l'ajout du trésor à l'inventaire*/
int add_tresor(Perso * hero, Terrain * chemin, Coord tresor_found){
	int empty_place;
	/* variable qui récupèrent les coordonnées de l'emplacement vide pour le trésor de l'inventaire*/
	int x,y;
	int i;
	Equipement eq1;
	Potion pot1;
	int valide_ajout = 1;
	/* on parcorut le coffre et on regarde si l'emplacement correspond à un équipement ou une potion*/
	for(i =0 ; i < NB_TRESOR; i++){
		/* si le deuxième objet du coffre est un équipement alors...*/
		if(chemin->terrain[tresor_found.x][tresor_found.y].entity.treasure[i].type_tresor == EQUIPEMENT){
			/* on vérifie s'il y a un emplacement vide*/
			empty_place = find_empty_place_1(*hero, &x, &y);
			/* s'il y a un emplacement vide alors on ajoute l'équipement*/
			if(empty_place == TRUE){
				/* l'ajout est un succès*/
				valide_ajout = 0;
				show_equipement(chemin->terrain[tresor_found.x][tresor_found.y].entity.treasure[i].item.eq);
				eq1 = chemin->terrain[tresor_found.x][tresor_found.y].entity.treasure[i].item.eq;
				add_equipement_invent(hero, eq1,x,y);
				chemin->terrain[tresor_found.x][tresor_found.y].entity.treasure[i].type_tresor = VIDE;
			}
			else
				printf("Votre inventaire des équipements est plein, veuillez le vider pour ajouter un objet\n");
		}

		else if(chemin->terrain[tresor_found.x][tresor_found.y].entity.treasure[i].type_tresor == POTION){
			/* on vérifie s'il y a un emplacement vide*/
			empty_place = find_empty_place_2(*hero, &x, &y);
			/* s'il y a un emplacement vide alors on ajoute la potion*/
			if(empty_place == TRUE){
				/* l'ajout est un succès*/
				valide_ajout = 0;
				show_potion(chemin->terrain[tresor_found.x][tresor_found.y].entity.treasure[i].item.pot);
				pot1 = chemin->terrain[tresor_found.x][tresor_found.y].entity.treasure[i].item.pot;
				add_potion_invent(hero, pot1,x,y);
				chemin->terrain[tresor_found.x][tresor_found.y].entity.treasure[i].type_tresor = VIDE;
			}
			else
				printf("Votre inventaire des potions est plein, veuillez le vider pour ajouter un objet\n");
		}
	}
	/* le joueur a réussit à faire un ajout ou plus*/
	if(valide_ajout == 0)
		return TRUE;
	/* pas d'emplacement vide*/
	return FALSE;
}


/*lance le son lié à la découverte d'un coffre*/
/* si la variable vaut true (0) on coupe le son sinon on laisse*/
void treasure_sound(int off , MLV_Sound * tab_sound[NB_SOUND]){
	int i;
	MLV_Sound *sound;
	sound = MLV_load_sound("Musique/Pieces.ogg");
	/* on arrête la musique*/
	if(off ==0){
			for(i =0; i < NB_SOUND ;i++){
				/* on regarde si la musique était déjà présente et on la met en pause si c'est le cas*/
				if(tab_sound[i] != NULL && tab_sound[i] == sound){
					MLV_free_sound(tab_sound[i]);
					tab_sound[i] = NULL;
					break;
				}
				
			}
			MLV_free_sound(sound);
			return;
	}
	/* cas où on lance la musique*/	
	for(i =0; i < NB_SOUND ;i++){
		/* on regarde si la musique était déjà présente*/
		if(tab_sound[i] != NULL && tab_sound[i] == sound)
			break;
		/* on ajoute la musique si elle n'était pas déjà présente*/
		else if(tab_sound[i] == NULL){
			tab_sound[i] = sound;
		}
	}
	MLV_free_sound(sound);
	/* on joue le son*/
	MLV_play_sound(tab_sound[i], 50);
}

/* lance le bruit de pas lié aux mouvements du héros*/
/* si la variable vaut true (0) on coupe le son sinon on laisse*/
void walk_sound(int off , MLV_Sound * tab_sound[NB_SOUND]){
	int i;
	MLV_Sound *sound;
	sound = MLV_load_sound("Musique/Marche.ogg");
	/* on arrête la musique*/
	if(off ==0){
			for(i =0; i < NB_SOUND ;i++){
				/* on regarde si la musique était déjà présente et on la met en pause si c'est le cas*/
				if(tab_sound[i] != NULL && tab_sound[i] == sound){
					MLV_free_sound(tab_sound[i]);
					tab_sound[i] = NULL;
					break;
				}
				
			}
			MLV_free_sound(sound);
			return;
	}
	for(i =0; i < NB_SOUND ;i++){
		/* on regarde si la musique était déjà présente*/
		if(tab_sound[i] != NULL && tab_sound[i] == sound)
			break;
		/* on ajoute la musique si elle n'était pas déjà présente*/
		else if(tab_sound[i] == NULL){
			tab_sound[i] = sound;
		}
	}
	MLV_free_sound(sound);
	/* on joue le son*/
	MLV_play_sound(tab_sound[i], 50);

}

/* lance le son lié à l'apparition d'un monstre*/
/* si la variable vaut true (0) on coupe le son sinon on laisse*/
void monster_sound(int off , MLV_Sound * tab_sound[NB_SOUND]){
	int i;
	MLV_Sound *sound;
	/* on arrête la musique*/
	if(off ==0){
			for(i =0; i < NB_SOUND ;i++){
				/* on regarde si la musique était déjà présente et on la met en pause si c'est le cas*/
				if(tab_sound[i] != NULL && tab_sound[i] == sound){
					MLV_free_sound(tab_sound[i]);
					tab_sound[i] = NULL;
					break;
				}
				
			}
			MLV_free_sound(sound);
			return;
	}
	sound = MLV_load_sound("Musique/Marche.ogg");
	for(i =0; i < NB_SOUND ;i++){
		/* on regarde si la musique était déjà présente*/
		if(tab_sound[i] != NULL && tab_sound[i] == sound)
			break;
		/* on ajoute la musique si elle n'était pas déjà présente*/
		else if(tab_sound[i] == NULL){
			tab_sound[i] = sound;
		}
	}
	MLV_free_sound(sound);
	/* on joue le son*/
	MLV_play_sound(tab_sound[i], 50);

}

/* lance le son lors d'une attaque*/
/* si la variable vaut true (0) on coupe le son sinon on laisse*/
void fight_sound(int off, MLV_Sound * tab_sound[NB_SOUND]){
	int i;
	MLV_Sound *sound;
	/* on arrête la musique*/
	if(off ==0){
			for(i =0; i < NB_SOUND ;i++){
				/* on regarde si la musique était déjà présente et on la met en pause si c'est le cas*/
				if(tab_sound[i] != NULL && tab_sound[i] == sound){
					MLV_free_sound(tab_sound[i]);
					tab_sound[i] = NULL;
					break;
				}
				
			}
			MLV_free_sound(sound);
			return;
	}
	sound = MLV_load_sound("Musique/Sword_fight.ogg");
	for(i =0; i < NB_SOUND ;i++){
		/* on regarde si la musique était déjà présente*/
		if(tab_sound[i] != NULL && tab_sound[i] == sound)
			break;
		/* on ajoute la musique si elle n'était pas déjà présente*/
		else if(tab_sound[i] == NULL){
			tab_sound[i] = sound;
		}
	}
	MLV_free_sound(sound);
	/* on joue le son*/
	MLV_play_sound(tab_sound[i], 50);

}

/* lance la musique de combat*/
/* si la variable vaut true (0) on coupe le son sinon on laisse*/
void fight_music(int off, MLV_Music * tab_music[NB_MUSIC], MLV_Sound * tab_sound[NB_SOUND]){
	int i;
	MLV_Sound *sound;
	MLV_Music *music;
	/* cas où on veut mettre en pause la musique*/
	if(off ==0){
			for(i =0; i < NB_MUSIC ;i++){
				/* on regarde si la musique était déjà présente et on la met en pause si c'est le cas*/
				if(tab_music[i] != NULL && tab_music[i] == music){
					MLV_free_music(tab_music[i]);
					tab_music[i] = NULL;
					break;
				}
			}
			MLV_free_music(music);
			return;
	}
	sound = MLV_load_sound("Musique/Sword_fight.ogg");
	for(i =0; i < NB_MUSIC ;i++){
		/* on regarde si la musique était déjà présente*/
		if(tab_sound[i] != NULL && tab_sound[i] == sound)
			break;
		/* on ajoute la musique si elle n'était pas déjà présente*/
		else if(tab_sound[i] == NULL){
			tab_sound[i] = sound;
		}
	}
	/* on joue le son*/
	MLV_play_sound(tab_sound[i], 50);
	MLV_free_sound(sound);
	monster_sound(off, tab_sound);

	music = MLV_load_music("Musique/Heros.mp3");

	for(i =0; i < NB_MUSIC ;i++){
		/* on regarde si la musique était déjà présente*/
		if(tab_music[i] != NULL && tab_music[i] == music)
			break;
		/* on ajoute la musique si elle n'était pas déjà présente*/
		else if(tab_music[i] == NULL){
			tab_music[i] = music;
		}
	}

	MLV_free_music(music);

	/* on joue la musique */
	MLV_play_music(tab_music[i], 5, -1);
}

/* coupe la musique*/
/* si la variable vaut true (0) on coupe le son sinon on laisse*/
void music_off(){
	MLV_Music *music;
	music = MLV_load_music("Musique/Heros.mp3");
	MLV_free_music(music);
}
